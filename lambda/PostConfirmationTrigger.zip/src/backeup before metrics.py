import json
import logging
from botocore.exceptions import ClientError
from datetime import datetime, timezone, timedelta
import boto3
from notifications import construct_notification_message, invoke_view_shop_info, trigger_notification_lambda

# Logger setup
logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.client('dynamodb', region_name='us-east-1')
cloudwatch = boto3.client('cloudwatch', region_name='us-east-1')


def lambda_handler(event, context):
    logger.info("Post Signup confirmation event received: %s", json.dumps(event, indent=2))

    # Extract user attributes from the event
    user_attributes = event['request']['userAttributes']
    customer_id = user_attributes['sub']
    laundry_id = user_attributes.get('custom:laundryId', '')
    email = user_attributes.get('custom:emailId', '')
    phone_number = user_attributes.get('phone_number', '')
    first_name = user_attributes.get('custom:firstName', '')
    last_name = user_attributes.get('custom:lastName', '')
    # TODO: create new attribute custom:emailNotification in the user pool to record instead of hard coding the value
    notification_preferences = {
        'email': user_attributes.get('custom:emailNotification', 'true').lower() == 'true',
        'phone': user_attributes.get('custom:phoneNotification', 'false').lower() == 'true'
    }

    timestamp = get_iso_timestamp()
    table_name = "Customer"

    try:
        # Log the input payload
        logger.info("Inserting record into DynamoDB...")
        # Default structure for laundryStats
        default_laundry_stats = {
            "currentOrders": {"L": []},
            "lastCompletedOrder": {"M": {}},
            "totalOrderValue": {"N": "0.0"},
            "totalOrdersPlaced": {"N": "0"}
        }
        payload = {
            "TableName": table_name,
            "Item": {
                "customerId": {"S": customer_id},
                "laundryId": {"L": [{"S": laundry_id}]},
                "email": {"S": email},
                "phoneNumber": {"S": phone_number},
                "firstName": {"S": first_name},
                "lastName": {"S": last_name},
                "notification_preferences": {
                    "M": {
                        "email": {"BOOL": notification_preferences['email']},
                        "phone": {"BOOL": notification_preferences['phone']}
                    }
                },
                "customerPaymentId": {"M": {}},
                "addresses": {"L": []},
                "createdAt": {"S": timestamp},
                "updatedAt": {"S": timestamp},
                "laundryStats": {
                    "M": {
                        laundry_id: {"M": default_laundry_stats}
                    }
                }
            }
        }
        dynamodb.put_item(**payload)
        logger.info("Customer Info added successfully to DynamoDB: %s", customer_id)
        # Trigger Lambda to get shop details
        shop_details = invoke_view_shop_info(laundry_id)
        logger.info("Retrieved laundry shop details: %s", shop_details)
        # extract the shop details from the lambda
        shop_name = shop_details.get("name", "laundry service")
        notification_message = construct_notification_message(first_name, shop_name)  # construct the notification
        # content for the welcome messages
        shop_email = shop_details.get("email")

        # Trigger notification Lambda to send welcome email and sms to the customer
        trigger_notification_lambda(
            notification_preferences,
            notification_message["email"],
            notification_message["sms"],
            email,
            phone_number,
            shop_email,
            shop_name
        )
        return event
    except ClientError as e:
        logger.error("Error processing Lambda function: %s", str(e))
        return {"statusCode": 500, "body": json.dumps({"message": "Internal Server Error"})}


# Get the current UTC timestamp
def get_iso_timestamp():
    # Get the current UTC time
    utc_now = datetime.now(timezone.utc)
    # Format it as ISO 8601 with 'Z'
    return utc_now.isoformat().replace("+00:00", "Z")
