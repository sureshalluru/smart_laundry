from botocore.exceptions import ClientError
import boto3
import logging
import json

# Logger setup
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize DynamoDB and Lambda clients
lambda_client = boto3.client('lambda', region_name='us-east-1')


# Construct Customer Welcome Message for the Email and phone number
def construct_notification_message(first_name, shop_name):
    # HTML formatted email message with styling
    email_message = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {{
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                margin: 0;
                padding: 0;
                background-color: #f9f9f9;
            }}
            p {{
                margin: 0 0 10px;
            }}
            .section-title {{
                font-size: 16px;
                font-weight: bold;
                margin-top: 15px;
            }}
            .highlight {{
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        <p>Dear <strong>{first_name}</strong>,</p>
        <p>Thank you for creating an account with <strong>{shop_name}</strong>. We are truly delighted to welcome you 
        to our community!</p> <p>Our team is committed to providing you with the best laundry services tailored to 
        your needs.</p> <p>If you have any questions, need assistance, or want to explore more about our services, 
        please don’t hesitate to contact us. We’re always here to help!</p> <p class="section-title">Thank you for 
        choosing <span class="highlight">{shop_name}</span> – we look forward to serving you.</p>
        <br>
        <p>Warm regards,</p>
        <p>The <strong>{shop_name}</strong> Team</p>
    </body>
    </html>
    """

    sms_message = (
        f"Hi {first_name}, thank you for creating an account with {shop_name}! "
        f"We're thrilled to have you as a customer. If you have any questions or need assistance, "
        f"please reach out. We look forward to serving you!"
    )

    return {"email": email_message, "sms": sms_message}


# Invoke Lambda function to ge the shop details
def invoke_view_shop_info(laundry_id):
    """
    Invoke the viewShopInfo operation to retrieve laundry shop details.
    """
    try:
        payload = {
            "queryStringParameters": {
                "operation": "viewShopInfo",
                "laundryId": laundry_id
            }
        }
        response = lambda_client.invoke(
            FunctionName="LaundryShopService",
            InvocationType="RequestResponse",
            Payload=json.dumps(payload)
        )
        response_payload = json.loads(response['Payload'].read().decode('utf-8'))

        if response_payload.get('statusCode') == 200:
            return response_payload['body']
        else:
            logger.error("Error from viewShopInfo: %s", response_payload)
            return {"error": "Unable to fetch shop details"}
    except ClientError as e:
        logger.error("Error invoking viewShopInfo Lambda: %s", str(e))
        return {"error": "Error invoking shop details Lambda"}


# Triggers the lambda code to send notifications to the customer
def trigger_notification_lambda(notification_preferences, email_message, sms_message, email, phone, shop_email,
                                shop_name):
    logger.info("Triggering notification Lambda...")
    logger.info("Notification Preferences: %s", notification_preferences)

    try:
        # check notification preferences for email
        if notification_preferences.get('email') and email:
            email_payload = {
                "type": "email",
                "recipient": email,
                "sender": shop_email,
                "subject": f"Welcome to {shop_name}",
                "message": email_message
            }
            logger.info("Email Payload: %s", email_payload)
            # Trigger the lambda function to send email notifications
            email_response = lambda_client.invoke(
                FunctionName="customerNotificationService",
                InvocationType="Event",
                Payload=json.dumps(email_payload)
            )
            logger.info("Email Lambda Response: %s", email_response)

        # check notification preferences for sms
        if notification_preferences.get('phone') and phone:
            sms_payload = {
                "type": "sms",
                "recipient": phone,
                "message": sms_message
            }
            logger.info("SMS Payload: %s", sms_payload)
            # Trigger the lambda function to send sms notifications
            sms_response = lambda_client.invoke(
                FunctionName="customerNotificationService",
                InvocationType="Event",
                Payload=json.dumps(sms_payload)
            )
            logger.info("SMS Lambda Response: %s", sms_response)

    except ClientError as e:
        logger.error("Error triggering notification Lambda: %s", str(e))
