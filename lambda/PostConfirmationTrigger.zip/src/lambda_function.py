"""
PostConfirmationTrigger — inserts new customer into PostgreSQL on Cognito signup.
"""
import json
import logging
import boto3
from datetime import datetime, timezone
import db

logger = logging.getLogger()
logger.setLevel(logging.INFO)

cloudwatch = boto3.client('cloudwatch', region_name='us-east-1')
lambda_client = boto3.client('lambda')


def lambda_handler(event, context):
    logger.info("PostConfirmationTrigger: %s", json.dumps(event, indent=2))
    attrs = event['request']['userAttributes']
    customer_id = attrs['sub']
    laundry_id  = attrs.get('custom:laundryId', '')
    email       = attrs.get('custom:emailId', '')
    phone       = attrs.get('phone_number', '')
    first_name  = attrs.get('custom:firstName', '')
    last_name   = attrs.get('custom:lastName', '')
    notif_email = attrs.get('custom:emailNotification', 'true').lower() == 'true'
    notif_phone = attrs.get('custom:phoneNotification', 'false').lower() == 'true'
    now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    try:
        cur = db.get_cursor()

        # Insert customer
        cur.execute("""
            INSERT INTO shop.customers
                (customer_id, first_name, last_name, email, phone_number,
                 notif_email, notif_sms, notif_phone, created_at, updated_at)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            ON CONFLICT (customer_id) DO NOTHING
        """, (customer_id, first_name, last_name, email, phone,
              notif_email, True, notif_phone, now, now))

        # Insert laundry stats row
        if laundry_id:
            cur.execute("""
                INSERT INTO shop.customer_laundry_stats (customer_id, laundry_id)
                VALUES (%s, %s)
                ON CONFLICT (customer_id, laundry_id) DO NOTHING
            """, (customer_id, laundry_id))

        db.commit()
        logger.info("Customer %s inserted successfully", customer_id)
        publish_metric("SuccessfulRegistrations", 1)

        # Send welcome notification
        try:
            shop_resp = lambda_client.invoke(
                FunctionName="ValidationService",
                InvocationType="RequestResponse",
                Payload=json.dumps({"queryStringParameters": {"operation": "getLaundryInfo", "laundryId": laundry_id}}).encode()
            )
            shop_body = json.loads(json.loads(shop_resp['Payload'].read()).get("body", "{}"))
            shop_name = shop_body.get("laundryName", "our laundry service")
            shop_email = shop_body.get("contactEmail", "")

            notif_payload = {
                "type": "email",
                "recipient": email,
                "sender": shop_email,
                "subject": f"Welcome to {shop_name}!",
                "message": f"<p>Hi {first_name}, welcome to {shop_name}! We're glad to have you.</p>"
            }
            lambda_client.invoke(
                FunctionName="customerNotificationService",
                InvocationType="Event",
                Payload=json.dumps(notif_payload).encode()
            )
        except Exception as notif_err:
            logger.warning("Welcome notification failed (non-fatal): %s", notif_err)

        return event

    except Exception as e:
        db.rollback()
        logger.exception("PostConfirmationTrigger error")
        publish_metric("FailedRegistrations", 1)
        return event  # Must return event for Cognito trigger


def publish_metric(metric_name, value):
    try:
        cloudwatch.put_metric_data(
            Namespace='CustomerRegistration',
            MetricData=[{"MetricName": metric_name, "Timestamp": datetime.utcnow(), "Value": float(value), "Unit": "Count"}]
        )
    except Exception as e:
        logger.warning("CloudWatch metric failed: %s", e)
