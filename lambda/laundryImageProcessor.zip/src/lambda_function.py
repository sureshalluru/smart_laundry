import base64
import boto3
import uuid
from datetime import datetime, timezone
import json
import logging
import os
from decimal import Decimal
import re
import binascii

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
TABLE_NAME = os.environ.get("TABLE_NAME", "LaundryGarmentMetadata")
LAUNDRY_SHOP_TABLE = os.environ.get("LAUNDRY_SHOP_TABLE", "LaundryShopInfo")
ORDERS_TABLE = os.environ.get("ORDERS_TABLE", "LaundryOrders")


def _error_response(status_code, message):
    """Helper function to create error responses"""
    logger.error(f"Returning error response: {status_code} - {message}")
    return {
        "statusCode": status_code,
        "body": json.dumps({"error": message})
    }


def get_current_timestamp():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def validate_base64_image(image_base64):
    """Validate if the base64 string is a valid JPG or PNG image"""
    logger.info("Starting image validation")
    try:
        # Check if it's a valid base64 string
        if not re.match(r'^[A-Za-z0-9+/]*={0,2}$', image_base64):
            logger.warning("Invalid base64 format detected")
            return False, "Invalid base64 format"

        # Decode the image
        logger.info("Decoding base64 image")
        image_bytes = base64.b64decode(image_base64)
        logger.info(f"Image decoded successfully, size: {len(image_bytes)} bytes")

        # Validate image format - only accept JPG or PNG
        if len(image_bytes) < 8:  # Minimum size for image headers
            logger.warning("Image too small or corrupted")
            return False, "Image too small or corrupted"

        # Check for JPEG magic numbers: FF D8 FF
        is_jpg = (image_bytes[0] == 0xFF and image_bytes[1] == 0xD8 and
                  image_bytes[2] == 0xFF and image_bytes[3] in [0xE0, 0xE1, 0xE8])

        # Check for PNG magic numbers: 89 50 4E 47 0D 0A 1A 0A
        is_png = (image_bytes[0] == 0x89 and image_bytes[1] == 0x50 and
                  image_bytes[2] == 0x4E and image_bytes[3] == 0x47 and
                  image_bytes[4] == 0x0D and image_bytes[5] == 0x0A and
                  image_bytes[6] == 0x1A and image_bytes[7] == 0x0A)

        if is_jpg:
            logger.info("Image format: JPEG detected")
        elif is_png:
            logger.info("Image format: PNG detected")
        else:
            logger.warning("Unsupported image format. Only JPG and PNG are supported")
            return False, "Only JPG and PNG image formats are supported"

        logger.info("Image validation successful")
        return True, image_bytes

    except (ValueError, binascii.Error) as e:
        logger.error(f"Base64 decoding error: {str(e)}")
        return False, f"Invalid base64 encoding: {str(e)}"
    except Exception as e:
        logger.error(f"Unexpected error during image validation: {str(e)}", exc_info=True)
        return False, f"Image validation failed: {str(e)}"

def validate_laundry_exists(laundry_id):
    """Check if laundryId exists in LaundryShopInfo table"""
    logger.info(f"Validating laundryId: {laundry_id}")
    try:
        table = dynamodb.Table(LAUNDRY_SHOP_TABLE)

        logger.info(f"Querying LaundryShopInfo table for laundryId: {laundry_id}")
        response = table.get_item(
            Key={'laundryId': laundry_id},
            ProjectionExpression='laundryId'
        )

        exists = 'Item' in response
        if exists:
            logger.info(f"LaundryId {laundry_id} found in database")
        else:
            logger.warning(f"LaundryId {laundry_id} not found in database")

        return exists, None

    except Exception as e:
        logger.error(f"Error validating laundryId {laundry_id}: {str(e)}", exc_info=True)
        return False, f"Error validating laundry: {str(e)}"

def validate_order_exists(laundry_id, order_id):
    """Check if orderId exists in LaundryOrders table for the given laundryId"""
    logger.info(f"Validating orderId: {order_id} for laundryId: {laundry_id}")
    try:
        table = dynamodb.Table(ORDERS_TABLE)

        logger.info(f"Querying LaundryOrders table for orderId: {order_id}")
        response = table.get_item(
            Key={
                'laundryId': laundry_id,
                'orderId': order_id
            },
            ProjectionExpression='orderId'
        )

        exists = 'Item' in response
        if exists:
            logger.info(f"OrderId {order_id} found in database")
        else:
            logger.warning(f"OrderId {order_id} not found in database for laundryId {laundry_id}")

        return exists, None

    except Exception as e:
        logger.error(f"Error validating order {order_id} for laundry {laundry_id}: {str(e)}", exc_info=True)
        return False, f"Error validating order: {str(e)}"

def lambda_handler(event, context):
    logger.info(f"Lambda invoked with event: {json.dumps(event)}")
    logger.info(f"Lambda context: {context}")

    try:
        # Parse and validate input
        logger.info("Parsing request body")
        body = json.loads(event.get("body", "{}"))
        logger.info(f"Parsed body: {json.dumps(body)}")

        # Required fields validation
        required_fields = ['laundryId', 'orderId', 'category', 'beforeOrAfter', 'imageBase64']
        missing_fields = [field for field in required_fields if field not in body]

        if missing_fields:
            logger.warning(f"Missing required fields: {missing_fields}")
            return _error_response(400, f"Missing required fields: {', '.join(missing_fields)}")

        laundry_id = body["laundryId"]
        order_id = body["orderId"]
        category = body["category"]
        stage = body["beforeOrAfter"]
        image_base64 = body["imageBase64"]
        env = body.get('env', 'dev')

        logger.info(f"Processing request - Laundry: {laundry_id}, Order: {order_id}, Category: {category}, Stage: {stage}")

        if stage not in ["BeforeWash", "AfterWash"]:
            logger.warning(f"Invalid stage value: {stage}")
            return _error_response(400, f"Invalid stage value: {stage}")

        # Validate image format (only JPG/PNG)
        logger.info("Starting image validation")
        is_valid_image, image_result = validate_base64_image(image_base64)
        if not is_valid_image:
            logger.warning(f"Image validation failed: {image_result}")
            return _error_response(400, image_result)

        image_bytes = image_result
        image_format = "jpg" if image_bytes[0] == 0xFF and image_bytes[1] == 0xD8 else "png"
        logger.info(f"Image validated successfully as {image_format.upper()}")

        # Validate laundry exists
        logger.info(f"Validating laundryId: {laundry_id}")
        laundry_exists, error = validate_laundry_exists(laundry_id)
        if not laundry_exists:
            logger.warning(f"Laundry validation failed: {error}")
            return _error_response(400, error or f"LaundryId {laundry_id} not found")

        logger.info("Laundry validation successful")

        # TODO: Enable when the garment detection is production ready
        # Validate order exists
        # order_exists, error = validate_order_exists(laundry_id, order_id)
        # if not order_exists:
        #     return _error_response(400, error or f"OrderId {order_id} not found for laundry {laundry_id}")

        # Process image upload
        bucket_name = f"laundry-images-store-{env}"
        image_id = f"{uuid.uuid4().hex}.{image_format}"
        s3_key = f"{laundry_id}/{order_id}/{stage}/{category}/{image_id}"

        logger.info(f"Preparing S3 upload - Bucket: {bucket_name}, Key: {s3_key}")

        content_type = 'image/jpeg' if image_format == 'jpg' else 'image/png'

        logger.info("Uploading image to S3")
        s3.put_object(
            Bucket=bucket_name,
            Key=s3_key,
            Body=image_bytes,
            ContentType=content_type,
            Metadata={
                'laundryId': laundry_id,
                'orderId': order_id,
                'category': category,
                'stage': stage
            }
        )
        logger.info("S3 upload completed successfully")

        # Update DynamoDB
        logger.info("Updating DynamoDB metadata")
        update_dynamodb(
            laundry_id,
            order_id,
            category,
            stage,
            s3_key
        )
        logger.info("DynamoDB update completed successfully")

        logger.info("Image processing completed successfully")
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Image processed successfully"
            })
        }

    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error: {str(e)}", exc_info=True)
        return _error_response(400, "Invalid JSON in request body")
    except KeyError as e:
        logger.error(f"Missing required field: {str(e)}", exc_info=True)
        return _error_response(400, f"Missing required field: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error in lambda_handler: {str(e)}", exc_info=True)
        return _error_response(500, "Internal server error")

def update_dynamodb(laundry_id, order_id, category, stage, s3_key):
    logger.info(f"Starting DynamoDB update for laundry: {laundry_id}, order: {order_id}")
    table = dynamodb.Table(TABLE_NAME)
    pk = f"{laundry_id}#{order_id}"
    timestamp = get_current_timestamp()
    category_path = s3_key.rsplit('/', 1)[0] + "/"

    logger.info(f"Composite key: {pk}, Category path: {category_path}")

    # Determine which count fields to update based on stage
    doc_count_field = "beforeWashCount" if stage == "BeforeWash" else "afterWashCount"
    cat_count_field = "beforeCount" if stage == "BeforeWash" else "afterCount"
    path_field = "beforeWashPath" if stage == "BeforeWash" else "afterWashPath"

    logger.info(f"Using fields - Document: {doc_count_field}, Category: {cat_count_field}, Path: {path_field}")

    # First try to update existing category
    try:
        logger.info("Attempt 1: Updating existing category")
        update_expr = f"""
        SET lastUpdated = :ts,
            {doc_count_field} = if_not_exists({doc_count_field}, :zero) + :inc,
            categories.#cat.{cat_count_field} = if_not_exists(categories.#cat.{cat_count_field}, :zero) + :inc,
            categories.#cat.#path = :path_val
        """

        table.update_item(
            Key={"laundryId#orderId": pk},
            UpdateExpression=update_expr,
            ExpressionAttributeNames={
                "#cat": category,
                "#path": path_field
            },
            ExpressionAttributeValues={
                ":ts": timestamp,
                ":inc": Decimal(1),
                ":zero": Decimal(0),
                ":path_val": category_path
            }
        )
        logger.info("Successfully updated existing category")
        return

    except dynamodb.meta.client.exceptions.ClientError as e:
        if e.response['Error']['Code'] != 'ValidationException':
            logger.error(f"DynamoDB client error: {str(e)}", exc_info=True)
            raise
        logger.info("Category or document doesn't exist, trying alternative approach")

    # If we get here, either the category or document doesn't exist
    try:
        logger.info("Attempt 2: Creating category structure")
        update_expr = f"""
        SET lastUpdated = :ts,
            {doc_count_field} = if_not_exists({doc_count_field}, :zero) + :inc,
            categories.#cat = if_not_exists(categories.#cat, :new_category)
        """

        table.update_item(
            Key={"laundryId#orderId": pk},
            UpdateExpression=update_expr,
            ExpressionAttributeNames={
                "#cat": category
            },
            ExpressionAttributeValues={
                ":ts": timestamp,
                ":inc": Decimal(1),
                ":zero": Decimal(0),
                ":new_category": {
                    cat_count_field: 1,
                    path_field: category_path
                }
            }
        )
        logger.info("Successfully created category structure")

    except dynamodb.meta.client.exceptions.ClientError as e:
        if e.response['Error']['Code'] != 'ValidationException':
            logger.error(f"DynamoDB client error: {str(e)}", exc_info=True)
            raise

        # Document doesn't exist, create full structure
        logger.info("Attempt 3: Creating new document with full structure")
        initial_counts = {
            "beforeWashCount": Decimal(1) if stage == "BeforeWash" else Decimal(0),
            "afterWashCount": Decimal(1) if stage == "AfterWash" else Decimal(0)
        }

        table.put_item(
            Item={
                "laundryId#orderId": pk,
                "lastUpdated": timestamp,
                **initial_counts,
                "categories": {
                    category: {
                        "beforeCount": 1 if stage == "BeforeWash" else 0,
                        "afterCount": 1 if stage == "AfterWash" else 0,
                        path_field: category_path
                    }
                }
            }
        )
        logger.info("Successfully created new document")