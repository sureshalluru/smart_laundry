// PreSignUp Lambda function
export const handler = async (event) => {
  console.log("PreSignUp event:", JSON.stringify(event, null, 2));

  // Access user attributes
  const phoneNumber = event.request.userAttributes.phone_number;
  const firstName = event.request.userAttributes['custom:firstName'];
  const lastName = event.request.userAttributes['custom:lastName'];
  const email = event.request.userAttributes['custom:emailId'];
  const inStore = event.request.userAttributes['custom:inStore'];

  // Validate required attributes
  if (!phoneNumber || !firstName || !lastName || !email || !inStore) {
    // Throw an error to prevent sign-up
    throw new Error('Missing required attributes: phone number, first name, last name,email or inStore Sign Up.');
  }

  if (inStore === 'true') {
    // Auto confirm the user if InStore is true
    event.response.autoConfirmUser = true;
    event.response.autoVerifyPhone = true;
    // event.response.autoVerifyEmail = true;
    console.log('Confirmed the User and Phone Number in the Cognito');
  }

  return event;
};
