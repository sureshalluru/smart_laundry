from datetime import datetime, timedelta, timezone
import boto3
import json
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
lambda_client = boto3.client('lambda')

orders_table = dynamodb.Table('LaundryOrders')
PAYMENT_LAMBDA_NAME = 'PaymentService'

TEST_LAUNDRY_ID = "test"  # Change this if you need to filter a specific test laundryId

def round_decimal(value):
    return float(round(Decimal(value), 2))

def lambda_handler(event, context):
    now = datetime.now(timezone.utc)
    # Define start and end of the "2 days ago" window
    start_time = datetime(now.year, now.month, now.day, tzinfo=timezone.utc) - timedelta(days=1)
    end_time = start_time + timedelta(days=1)

    start_iso = start_time.isoformat()
    end_iso = end_time.isoformat()

    print(f"[INFO] Capturing payments for orders created between {start_iso} and {end_iso}")


    print(f"[INFO] Lambda started at: {now.isoformat()}")
    print(f"[INFO] Filtering by test laundryId: {TEST_LAUNDRY_ID}")

    scan_kwargs = {
        'FilterExpression': (
            '(#ot = :online OR #ot = :instore) AND #ps <> :paid AND attribute_exists(customerPaymentId) '
            'AND createdAt BETWEEN :start AND :end AND laundryId = :lid'
        ),
        'ExpressionAttributeNames': {
            '#ot': 'orderType',
            '#ps': 'paymentStatus'
        },
        'ExpressionAttributeValues': {
            ':online': 'Online',
            ':instore': 'InStore',
            ':paid': 'Paid',
            ':start': start_iso,
            ':end': end_iso,
            ':lid': TEST_LAUNDRY_ID
        }
    }


    try:
        print(f"[DEBUG] scan_kwargs => {json.dumps(scan_kwargs, default=str)}")

        response = orders_table.scan(**scan_kwargs)
        orders = response.get('Items', [])
        print(f"[INFO] Found {len(orders)} unpaid orders eligible for capture.")

        success_count = 0
        failure_logs = []

        for order in orders:
            print(f"[DEBUG] Processing order: {json.dumps(order, default=str)}")

            order_id = order['orderId']
            order_type = order.get('orderType')
            payment_status = order.get('paymentStatus')
            created_at = order.get('createdAt')
            laundry_id = order.get('laundryId')
            customer_payment_id = order.get('customerPaymentId')

            print(f"[CHECK] OrderId: {order_id}, Type: {order_type}, Status: {payment_status}, Created: {created_at}, LaundryId: {laundry_id}")

            amount = Decimal(order.get('grandTotal') or order.get('totalCost') or 0)

            if order_type == "Online":
                print(f"[INFO] Attempting payment capture for Online order: {order_id}, Amount: {amount}")

                payment_payload = {
                    "orderId": order_id,
                    "amount": round_decimal(amount),
                    "description": f"Auto capture for Online order {order_id}",
                    "customerPaymentId": customer_payment_id,
                    "laundryId": laundry_id,
                    "orderPaymentOperation": "capturePayment",
                    "customerId": order["customerId"]
                }

                print(f"[DEBUG] Sending payment payload: {json.dumps(payment_payload)}")

                try:
                    payment_response = lambda_client.invoke(
                        FunctionName=PAYMENT_LAMBDA_NAME,
                        InvocationType='RequestResponse',
                        Payload=json.dumps(payment_payload)
                    )

                    result = json.loads(payment_response['Payload'].read())
                    print(f"[DEBUG] PaymentService response for order {order_id}: {result}")

                    if result.get("status") == "success":
                        orders_table.update_item(
                            Key={'orderId': order_id},
                            UpdateExpression="SET paymentStatus = :ps",
                            ExpressionAttributeValues={':ps': 'Paid'}
                        )
                        print(f"[SUCCESS] Payment captured for Online order: {order_id}")
                        success_count += 1
                    else:
                        print(f"[FAILED] Payment failed for order {order_id}: {result.get('message')}")
                        failure_logs.append({'orderId': order_id, 'error': result.get('message')})

                except Exception as e:
                    print(f"[ERROR] Exception during payment for order {order_id}: {str(e)}")
                    failure_logs.append({'orderId': order_id, 'error': str(e)})

            else:
                print(f"[SKIP] Skipping non-online order: {order_id}, Type: {order_type}")

        return {
            "statusCode": 200,
            "body": {
                "timestamp": now.isoformat(),
                "ordersProcessed": len(orders),
                "successfulCaptures": success_count,
                "failures": failure_logs
            }
        }

    except Exception as e:
        print(f"[FATAL] Error during payment reconciliation: {str(e)}")
        return {
            "statusCode": 500,
            "body": {
                "error": str(e)
            }
        }
