import boto3
import json
import logging

# Configure logging for CloudWatch Logs
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Initialize AWS Lambda client
lambda_client = boto3.client('lambda')

# Function to invoke the customerNotificationService Lambda
def send_sms_notification(phone_number, otp_code):
    try:
        # Prepare payload for customerNotificationService Lambda
        payload = {
            "type": "sms",
            "recipient": phone_number,
            "message": f"{otp_code} is the OTP to log in to your laundry account. DO NOT share this code with anyone."
        }

        # Log the invocation with payload details
        logger.info("Invoking customerNotificationService with payload: %s", json.dumps(payload))

        # Invoke the Lambda function asynchronously
        response = lambda_client.invoke(
            FunctionName="customerNotificationService",
            InvocationType="Event",
            Payload=json.dumps(payload)
        )

        # Log the response from the asynchronous invocation
        logger.info("Asynchronous invoke response: %s", response)
        logger.info("SMS notification invoked successfully.")

    except Exception as e:
        # Log the exception with stack trace
        logger.exception("Error invoking customerNotificationService: %s", str(e))
        raise Exception("Failed to send OTP")
