import json
import random
import logging
from notifications import send_sms_notification

# Configure logging for CloudWatch Logs
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Function to generate a random 6-digit OTP
def generate_otp():
    otp = str(random.randint(100000, 999999))  # Uncomment for random OTP
    # otp = "121212"  # Hardcoded for testing purposes
    logger.info("Generated OTP: %s", otp)
    return otp

# Lambda handler function
def lambda_handler(event, context):
    logger.info("Lambda function invoked.")
    logger.info("Received event in the Create Auth Challenge: %s", event)

    otp_code = None
    MAX_ATTEMPTS = 3

    # Extract session and user attributes
    session = event.get("request", {}).get("session", [])
    user_attributes = event.get("request", {}).get("userAttributes", {})
    phone_number = user_attributes.get("phone_number")
    logger.info("Extracted session: %s", session)
    logger.info("Extracted user attributes: %s", user_attributes)
    logger.info("User phone number: %s", phone_number)

    if not session or len(session) == 0:
        # New auth session: Generate a new OTP
        logger.info("No existing session found, generating a new OTP.")
        otp_code = generate_otp()  # Generate a random 6-digit OTP
        logger.info("Sending SMS notification to %s with OTP: %s", phone_number, otp_code)
        send_sms_notification(phone_number, otp_code)  # Use customerNotificationService Lambda
    else:
        # Existing session: Reuse the previous OTP
        logger.info("Existing session found, using previous OTP.")
        previous_challenge = session[-1]
        challenge_metadata = previous_challenge.get("challengeMetadata")
        if challenge_metadata:
            # Extract OTP code from the challenge metadata
            otp_code = challenge_metadata[5:] 
            logger.info("Reusing OTP from previous challenge: %s", otp_code)
        else:
            logger.warning("No challengeMetadata found in the previous session. Generating new OTP.")
            otp_code = generate_otp()
            logger.info("Sending SMS notification to %s with OTP: %s", phone_number, otp_code)
            send_sms_notification(phone_number, otp_code)

    # Calculate the number of attempts made and remaining attempts
    attempts = len(session)
    attempts_left = MAX_ATTEMPTS - attempts
    logger.info("Number of attempts: %d, Attempts left: %d", attempts, attempts_left)

    # Setting public and private challenge parameters for the client
    event["response"] = {
        "publicChallengeParameters": {
            "phoneNumber": phone_number,
            "maxAttempts": MAX_ATTEMPTS,
            "attempts": attempts,
            "attemptsLeft": attempts_left,
        },
        "privateChallengeParameters": {
            "secretLoginCode": otp_code
        },
        "challengeMetadata": f"CODE-{otp_code}"
    }

    logger.info("Final Create Auth Challenge Response: %s", json.dumps(event))
    return event
