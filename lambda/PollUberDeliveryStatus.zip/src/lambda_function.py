import requests
import uuid
import json
import boto3
from datetime import datetime
import pytz
import db

# === Uber Auth ===
def get_uber_access_token(client_id, client_secret):
    url = "https://auth.uber.com/oauth/v2/token"
    payload = {"grant_type": "client_credentials", "client_id": client_id,
               "client_secret": client_secret, "scope": "eats.deliveries"}
    response = requests.post(url, headers={"Content-Type": "application/x-www-form-urlencoded"}, data=payload)
    response.raise_for_status()
    return response.json()["access_token"]

# === PostgreSQL Lookup ===
def get_laundry_credentials(laundry_id, uber_env):
    cur = db.get_cursor()
    cur.execute("""
        SELECT luc.client_id, luc.client_secret, luc.customer_id, luc.base_url
        FROM shop.laundry_uber_credentials luc
        WHERE luc.laundry_id = %s AND luc.env = %s
    """, (laundry_id, uber_env))
    row = cur.fetchone()
    if not row:
        raise KeyError(f"Uber credentials not found for laundry {laundry_id} env {uber_env}")
    return {"clientId": row["client_id"], "clientSecret": row["client_secret"],
            "customerId": row["customer_id"], "baseUrl": row["base_url"]}

# === Get Delivery Status ===
def get_delivery_status(token, customer_id, base_url, delivery_id):
    url = f"{base_url}/customers/{customer_id}/deliveries/{delivery_id}"
    response = requests.get(url, headers={"Authorization": f"Bearer {token}"})
    response.raise_for_status()
    return response.json()

# === Lambda Entry ===
def lambda_handler(event, context):
    try:
        laundry_id  = event["laundry_id"]
        delivery_id = event["delivery_id"]
        uber_env    = event.get("uberEnv", "test")
        creds  = get_laundry_credentials(laundry_id, uber_env)
        token  = get_uber_access_token(creds["clientId"], creds["clientSecret"])
        status = get_delivery_status(token, creds["customerId"], creds["baseUrl"], delivery_id)
        return {"statusCode": 200, "body": json.dumps(status)}
    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}

