
# import os, json, time, logging, boto3, requests
# from boto3.dynamodb.conditions import Key, Attr
# from datetime import datetime
# from decimal import Decimal

# logger = logging.getLogger()
# logger.setLevel(logging.INFO)

# # UBER_BASE = "https://api.uber.com/v1"
# UBER_BASE         = "https://sandbox-api.uber.com/v1"
# UBER_CUSTOMER_ID = os.environ["TEST_UBER_CUSTOMER_ID"]
# CLIENT_ID = os.environ["TEST_UBER_CLIENT_ID"]
# CLIENT_SECRET = os.environ["TEST_UBER_CLIENT_SECRET"]

# uber_queue_table = boto3.resource("dynamodb").Table("UberOrderScheduleQueue")
# laundry_orders_table = boto3.resource("dynamodb").Table("LaundryOrders")

# _TOKEN, _EXP = None, 0

# def get_uber_token() -> str:
#     global _TOKEN, _EXP
#     now = time.time()
#     if _TOKEN and now < _EXP - 60:
#         return _TOKEN

#     logger.info("🔐 Refreshing Uber token")
#     resp = requests.post(
#         "https://auth.uber.com/oauth/v2/token",
#         headers={"Content-Type": "application/x-www-form-urlencoded"},
#         data={
#             "client_id": CLIENT_ID,
#             "client_secret": CLIENT_SECRET,
#             "grant_type": "client_credentials",
#             "scope": "eats.deliveries",
#         },
#         timeout=10,
#     )
#     resp.raise_for_status()
#     js = resp.json()
#     _TOKEN = js["access_token"]
#     _EXP = now + js["expires_in"]
#     return _TOKEN

# def poll_delivery_status(delivery_id: str, token: str):
#     url = f"{UBER_BASE}/customers/{UBER_CUSTOMER_ID}/deliveries/{delivery_id}"
#     r = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=10)
#     if r.ok:
#         return r.json()
#     logger.error(f"❌ Failed polling delivery {delivery_id}: {r.text}")
#     return None

# def lambda_handler(event, context):
#     logger.info("✅ PollUberDeliveryStatus triggered by EventBridge")
#     token = get_uber_token()
#     now_utc = datetime.utcnow()
#     now_ts = int(now_utc.timestamp() * 1000)
#     now_iso = now_utc.isoformat() + "Z"  

#     for laundry_id in ["test"]:  # Add all active laundryIds
#         logger.info(f"🔍 Polling Uber deliveries for laundryId: {laundry_id}")

#         response = uber_queue_table.query(
#             KeyConditionExpression=Key("laundryId").eq(laundry_id),
#             FilterExpression=Attr("scheduled").eq("true") & Attr("deliveryStatus").ne("delivered"),
#         )

#         for item in response.get("Items", []):
#             delivery_id = item.get("deliveryId")
#             order_id = item.get("orderId")
#             order_key = item.get("orderKey")

#             # Extract Uber type from orderKey like "Pickup#2025-07-11#O-12345"
#             uber_type = "Pickup" if order_key.startswith("Pickup#") else "Dropoff"

#             if not delivery_id:
#                 continue

#             status_resp = poll_delivery_status(delivery_id, token)
#             if not status_resp:
#                 continue

#             new_status = status_resp.get("status")
#             logger.info(f"🚚 Delivery {delivery_id} status: {new_status}")
#             logger.info(f"📦 Raw Uber response for delivery {delivery_id}: {json.dumps(status_resp)}")


#             updates = {
#                 "deliveryStatus": new_status,
#                 "lastPolledAt": now_ts
#             }

#             # 🔍 Determine Uber type
#             if order_key.startswith("Pickup#"):
#                 uber_type = "Pickup"
#             elif order_key.startswith("Dropoff#"):
#                 uber_type = "Dropoff"
#             else:
#                 logger.warning(f"⚠️ Unable to determine Uber type for orderKey: {order_key}")
#                 continue

#             # ✅ Pickup logic
#             if new_status == "delivered" and uber_type == "Pickup" and not item.get("pickupCompletedAt"):
#                 updates["pickupCompletedAt"] = now_ts
#                 laundry_orders_table.update_item(
#                     Key={"orderId": order_id},
#                     UpdateExpression="""
#                         SET uberPickupCompletedAt = :ts,
#                             orderStatus = :status,
#                             updatedAt = :updated
#                     """,
#                     ExpressionAttributeValues={
#                         ":ts": now_ts,
#                         ":status": "ReceivedAtFacility",
#                         ":updated": now_iso
#                     }
#                 )
#                 logger.info(f"✅ Pickup complete for {order_id}, updated orderStatus to ReceivedAtFacility")

#             # ✅ Dropoff logic
#             if new_status == "delivered" and uber_type == "Dropoff" and not item.get("dropoffCompletedAt"):
#                 updates["dropoffCompletedAt"] = now_ts
#                 laundry_orders_table.update_item(
#                     Key={"orderId": order_id},
#                     UpdateExpression="""
#                         SET uberDropoffCompletedAt = :ts,
#                             orderStatus = :status,
#                             updatedAt = :updated
#                     """,
#                     ExpressionAttributeValues={
#                         ":ts": now_ts,
#                         ":status": "Delivered",
#                         ":updated": now_iso
#                     }
#                 )
#                 logger.info(f"✅ Dropoff complete for {order_id}, updated orderStatus to Delivered")

#             # ✅ Update UberOrderScheduleQueue
#             uber_queue_table.update_item(
#                 Key={"laundryId": laundry_id, "orderKey": order_key},
#                 UpdateExpression="SET " + ", ".join(f"{k}=:{k}" for k in updates),
#                 ExpressionAttributeValues={f":{k}": v for k, v in updates.items()}
#             )

#     return {"statusCode": 200, "body": "Polling complete"}
