import json
import urllib.request
from jose import jwt
from jose.exceptions import JWTError

# Configuration for Cognito
COGNITO_USER_POOL_ID = "us-east-1_54Ly6WLVN"
APP_CLIENT_ID = "1nbbfeeuvlthdf6gr2ogos2jfp"
COGNITO_REGION = "us-east-1"
COGNITO_ISSUER = f"https://cognito-idp.{COGNITO_REGION}.amazonaws.com/{COGNITO_USER_POOL_ID}"
JWKS_URL = f"{COGNITO_ISSUER}/.well-known/jwks.json"

def lambda_handler(event, context):
    print("Received event:", event)
    headers = event.get('headers', {})
    
    # Try to extract the token from one of the possible header names
    token = headers.get('x-api-key') or headers.get('method.request.header.x-api-key')
    if not token:
        auth_header = event.get('authorizationToken', '')
        parts = auth_header.split(' ')
        token = parts[1] if len(parts) == 2 else auth_header

    if not token:
        print("No token found in headers")
        raise Exception("Unauthorized")

    # Retrieve the JWKS from Cognito
    try:
        with urllib.request.urlopen(JWKS_URL) as response:
            jwks = json.loads(response.read())
    except Exception as e:
        print(f"Error fetching JWKS: {str(e)}")
        raise Exception("Unauthorized")

    # Get the unverified header to extract the key id (kid)
    try:
        unverified_header = jwt.get_unverified_header(token)
        print("Unverified token header:", unverified_header)
    except JWTError as e:
        print(f"Invalid token header: {str(e)}")
        raise Exception("Unauthorized")

    kid = unverified_header.get("kid")
    if not kid:
        print("No kid found in token header")
        raise Exception("Unauthorized")

    # Look up the correct JWK in the JWKS using the kid
    key = None
    for jwk in jwks.get("keys", []):
        if jwk.get("kid") == kid:
            key = jwk
            break
    if key is None:
        print("Public key not found in JWKS for given kid")
        raise Exception("Unauthorized")

    # Decode the token while disabling audience verification (for access tokens)
    try:
        claims = jwt.decode(
            token,
            key,             # Passing the JWK; python-jose will convert it as needed.
            algorithms=["RS256"],
            issuer=COGNITO_ISSUER,
            options={"verify_aud": False}  # Disable audience checking
        )
        # Manually verify that the token's client_id matches APP_CLIENT_ID
        if claims.get("client_id") != APP_CLIENT_ID:
            print("Client ID mismatch in token")
            raise Exception("Unauthorized")
    except JWTError as e:
        print(f"Token validation error: {str(e)}")
        raise Exception("Unauthorized")

    # Retrieve laundryId from token's custom claim
    token_laundry_id = claims.get('custom:laundryId')

    # Extract laundryId from the request (path, query, or body parameters)
    path_params = event.get('pathParameters', {})
    query_params = event.get('queryStringParameters', {})
    try:
        body = json.loads(event.get('body', '{}'))
    except Exception:
        body = {}

    request_laundry_id = (
        path_params.get('laundryId') or
        query_params.get('laundryId') or
        body.get('laundryId')
    )

    if token_laundry_id != request_laundry_id:
        print(f"Laundry ID mismatch: token {token_laundry_id} vs request {request_laundry_id}")
        raise Exception("Unauthorized: Laundry ID mismatch")

    # Generate the IAM policy
    principal_id = claims.get("sub")
    method_arn = event["methodArn"]
    policy_document = {
        "Version": "2012-10-17",
        "Statement": [{
            "Action": "execute-api:Invoke",
            "Effect": "Allow",
            "Resource": method_arn
        }]
    }

    return {
        "principalId": principal_id,
        "policyDocument": policy_document,
        "context": {
            "laundryId": token_laundry_id,
            "role": claims.get("custom:role")
        }
    }
