export const handler = async (event) => {
    console.log("Event received:", JSON.stringify(event, null, 2));
  
    const MAX_ATTEMPTS = 3;  // Hardcoded the maximum number of allowed attempts
    const attempts = event.request.session.length;
    console.log("Number of attempts:", attempts);
  
    const lastAttempt = event.request.session[event.request.session.length - 1];
    console.log("Last attempt:", JSON.stringify(lastAttempt, null, 2));
    // If requested session is not custom challenge
    if (event.request.session &&
        event.request.session.find(attempt => attempt.challengeName !== 'CUSTOM_CHALLENGE')) {
        console.log("Non-CUSTOM_CHALLENGE found, failing authentication");
        event.response.issueTokens = false; // Fail to Issue Cognito Tokens
        event.response.failAuthentication = true;
    }
    // Too many wrong answers
    else if (attempts >= MAX_ATTEMPTS && lastAttempt.challengeResult === false) {
        console.log(`Exceeded max attempts (${MAX_ATTEMPTS}), failing authentication`);
        event.response.issueTokens = false;
        event.response.failAuthentication = true;
    }
    // Correct answer provided
    else if (attempts >= 1 &&
        lastAttempt.challengeName === 'CUSTOM_CHALLENGE' &&
        lastAttempt.challengeResult === true) {
        console.log("Correct answer provided, issuing tokens");
        event.response.issueTokens = true; // Issue Cognito Tokens
        event.response.failAuthentication = false;
    }
    // Wrong answer, allow retry
    else {
        console.log("Wrong answer or first attempt, prompting for CUSTOM_CHALLENGE again");
        event.response.issueTokens = false; // Fail to Issue Cognito Tokens
        event.response.failAuthentication = false;
        event.response.challengeName = 'CUSTOM_CHALLENGE';
    }
  
    console.log("Response to be returned:", JSON.stringify(event, null, 2));
  
    return event;
  };
  