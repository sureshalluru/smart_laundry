import { CognitoIdentityProviderClient, AdminConfirmSignUpCommand, AdminUpdateUserAttributesCommand } from "@aws-sdk/client-cognito-identity-provider";

const cognito = new CognitoIdentityProviderClient({ region: 'us-east-1' });

export const handler = async (event, context, callback) => {
    console.log('Event received in VerifyAuthChallenge:', JSON.stringify(event, null, 2));

    const expectedOtp = event.request.privateChallengeParameters.secretLoginCode;
    const userOtp = event.request.challengeAnswer;
    const userPoolId = event.userPoolId;
    const userName = event.userName;
    // Validate OTP
    if (expectedOtp === userOtp) {
        console.log('OTP verification successful.');
        event.response.answerCorrect = true; // Mark OTP as Verified

        try {
            // If the user is not confirmed in the cognito mark customer as confirmed
            if (event.request.userAttributes['cognito:user_status'] === 'UNCONFIRMED') {
                console.log('Confirming user...');
                await cognito.send(new AdminConfirmSignUpCommand({
                    UserPoolId: userPoolId,
                    Username: userName,
                }));
            }
            // Mark the phone number as verified in the cognito user pool
            console.log('Checking Verification Status of the phone number...');
            await cognito.send(new AdminUpdateUserAttributesCommand({
                UserPoolId: userPoolId,
                Username: userName,
                UserAttributes: [
                    { Name: 'phone_number_verified', Value: 'true' }
                ]
            }));

            // Manually update the userAttributes in the event object
            event.request.userAttributes['cognito:user_status'] = 'CONFIRMED';
            event.request.userAttributes['phone_number_verified'] = 'true';
            console.log('User is confirmed and phone number is verified in the cognito.')

        } catch (error) {
            console.error('Error during user confirmation or attribute update:', error);
            callback(new Error('Failed to confirm the user or update attributes.'), event);
            return;
        }

    } else {
        console.log('OTP verification failed.',JSON.stringify(event, null, 2));
        event.response.answerCorrect = false;
    }

    callback(null, event);
};
