"""
UncapturedPaymentsReconciler — auto-completes expiring InStore orders.
Migrated to PostgreSQL.
"""
import json
import logging
import boto3
from datetime import datetime, timedelta, timezone
import db

logger = logging.getLogger()
logger.setLevel(logging.INFO)

lambda_client = boto3.client('lambda')
ORDERS_INFORMATION_SERVICE_LAMBDA = 'OrdersInformationService'


def lambda_handler(event, context):
    threshold_days = int(event.get('thresholdDays', 2))
    dry_run = str(event.get('dryRun', False)).lower() == 'true'
    test_laundry_id = event.get('testLaundryId')
    return auto_complete_expiring_instore_orders(threshold_days, dry_run, test_laundry_id)


def auto_complete_expiring_instore_orders(threshold_days=2, dry_run=False, test_laundry_id=None):
    cutoff = datetime.now(tz=timezone.utc) - timedelta(days=threshold_days)
    logger.info("Scanning InStore orders created before %s (dry_run=%s)", cutoff.isoformat(), dry_run)

    try:
        cur = db.get_cursor()
        query = """
            SELECT order_id, laundry_id, last_updated_by, created_at,
                   order_type, order_status, status_category, payment_status
            FROM orders.orders
            WHERE order_type = 'InStore'
              AND status_category = 'Active'
              AND order_status IN ('ReceivedAtFacility', 'ProcessingCompleted')
              AND payment_status = 'Paid'
              AND created_at <= %s
        """
        params = [cutoff]
        if dry_run and test_laundry_id:
            query += " AND laundry_id = %s"
            params.append(test_laundry_id)

        cur.execute(query, params)
        eligible = cur.fetchall()
        logger.info("Found %d eligible orders", len(eligible))

        updated, failed = [], []

        for order in eligible:
            order_id = order["order_id"]
            laundry_id = order["laundry_id"]
            employee_id = order["last_updated_by"] or "SYSTEM"

            if dry_run:
                updated.append({"orderId": order_id, "laundryId": laundry_id, "dryRun": True})
                continue

            try:
                result = _invoke_update_order_status(order_id, laundry_id, employee_id)
                updated.append({"orderId": order_id, "laundryId": laundry_id, "result": result})
            except Exception as e:
                logger.exception("Failed to update order %s", order_id)
                failed.append({"orderId": order_id, "message": str(e)})

        return {
            "status": "success",
            "thresholdDays": threshold_days,
            "dryRun": dry_run,
            "eligibleOrders": len(eligible),
            "updated": len(updated),
            "failed": len(failed),
            "updatedDetails": updated,
            "failedDetails": failed,
        }
    except Exception as e:
        logger.exception("auto_complete_expiring_instore_orders error")
        return {"status": "error", "message": str(e)}


def _invoke_update_order_status(order_id, laundry_id, employee_id):
    payload = {
        "queryStringParameters": {
            "operation": "updateOrder",
            "orderId": order_id,
            "laundryId": laundry_id,
            "empId": employee_id,
        },
        "body": json.dumps({"orderStatus": "ProcessingCompleted", "coupon": None, "servicesToUpdate": []}),
    }
    resp = lambda_client.invoke(
        FunctionName=ORDERS_INFORMATION_SERVICE_LAMBDA,
        InvocationType='RequestResponse',
        Payload=json.dumps(payload).encode()
    )
    raw = resp['Payload'].read().decode()
    return json.loads(raw) if raw else {}
