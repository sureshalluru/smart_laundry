import boto3
import json
import logging
from datetime import datetime, timedelta, timezone
from boto3.dynamodb.conditions import Attr

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')
lambda_client = boto3.client('lambda')
orders_table = dynamodb.Table('LaundryOrders')

ORDERS_INFORMATION_SERVICE_LAMBDA = 'OrdersInformationService'


def lambda_handler(event, context):
    """
    Entry point for the scheduled Lambda.

    EventBridge rule payload (example):
    {
        "thresholdDays": 1,
        "dryRun": false
    }

    threshold_days : orders created >= this many days ago are considered expiring.
    dry_run        : when True, logs eligible orders but makes no changes.
    """
    threshold_days = event.get('thresholdDays', 2)
    dry_run = event.get('dryRun', False)
    test_laundry_id = event.get('testLaundryId')

    if isinstance(dry_run, str):
        dry_run = dry_run.lower() == 'true'
    try:
        threshold_days = int(threshold_days)
    except (TypeError, ValueError):
        threshold_days = 2

    return auto_complete_expiring_instore_orders(threshold_days=threshold_days, dry_run=dry_run, test_laundry_id=test_laundry_id)


# ---------------------------------------------------------------------------
# Core logic
# ---------------------------------------------------------------------------

def auto_complete_expiring_instore_orders(threshold_days=2, dry_run=False, test_laundry_id=None):
    """
    Scans LaundryOrders for InStore orders that are approaching (or past)
    their authorization hold window and have not yet been completed/paid.
    For each eligible order it calls OrdersInformationService to set the
    status to ProcessingCompleted so the downstream capture can proceed.
    """
    cutoff = datetime.now(tz=timezone.utc) - timedelta(days=threshold_days)
    logger.info(
        f"Scanning for InStore orders created before {cutoff.isoformat()} "
        f"(threshold={threshold_days}d, dry_run={dry_run})"
    )

    # Only pull the fields we need – avoids reading large product/service lists.
    projection = (
        "orderId, laundryId, lastUpdatedBy, createdAt, "
        "orderType, orderStatus, statusCategory, paymentStatus"
    )

    # DynamoDB filter: InStore orders that are still Active and whose
    # status is ReceivedAtFacility or ProcessingCompleted (hold may be expiring).
    filter_expression = (
        Attr('orderType').eq('InStore') &
        Attr('statusCategory').eq('Active') &
        Attr('orderStatus').is_in(['ReceivedAtFacility', 'ProcessingCompleted']) &
        Attr('paymentStatus').eq('Paid')
    )

    # In dry-run mode, restrict the scan to the test laundry only.
    if dry_run and test_laundry_id:
        filter_expression = filter_expression & Attr('laundryId').eq(test_laundry_id)
        logger.info(f"[DRY RUN] Restricting scan to testLaundryId={test_laundry_id}")

    eligible_orders = []
    parse_errors = []
    last_evaluated_key = None
    total_scanned = 0

    # Paginate through the full table.
    while True:
        scan_kwargs = {
            'ProjectionExpression': projection,
            'FilterExpression': filter_expression,
        }
        if last_evaluated_key:
            scan_kwargs['ExclusiveStartKey'] = last_evaluated_key

        response = orders_table.scan(**scan_kwargs)
        total_scanned += response.get('ScannedCount', 0)

        for order in response.get('Items', []):
            order_id = order.get('orderId', '<unknown>')
            created_at_raw = order.get('createdAt')

            try:
                created_at_dt = _parse_utc_timestamp(created_at_raw)
            except Exception as exc:
                logger.warning(f"[{order_id}] Cannot parse createdAt '{created_at_raw}': {exc}")
                parse_errors.append({'orderId': order_id, 'createdAt': created_at_raw, 'error': str(exc)})
                continue

            if created_at_dt and created_at_dt <= cutoff:
                eligible_orders.append(order)

        last_evaluated_key = response.get('LastEvaluatedKey')
        if not last_evaluated_key:
            break

    logger.info(f"Scan complete. scanned={total_scanned}, eligible={len(eligible_orders)}")

    updated, failed = [], []

    for order in eligible_orders:
        order_id = order['orderId']
        laundry_id = order.get('laundryId')
        # Use the last employee who touched the order; fall back to a system marker.
        employee_id = order.get('lastUpdatedBy') or 'SYSTEM'

        if not order_id or not laundry_id:
            logger.error(f"Skipping order with missing identifiers: {order}")
            failed.append({'orderId': order_id, 'laundryId': laundry_id, 'message': 'Missing orderId or laundryId'})
            continue

        if dry_run:
            logger.info(f"[DRY RUN] Would update orderId={order_id}, laundryId={laundry_id}, empId={employee_id}")
            updated.append({'orderId': order_id, 'laundryId': laundry_id, 'employeeId': employee_id, 'dryRun': True})
            continue

        try:
            result = _invoke_update_order_status(order_id, laundry_id, employee_id)
            logger.info(f"[{order_id}] Updated successfully. Response: {result}")
            updated.append({'orderId': order_id, 'laundryId': laundry_id, 'employeeId': employee_id, 'result': result})
        except Exception as exc:
            logger.exception(f"[{order_id}] Failed to update order status: {exc}")
            failed.append({'orderId': order_id, 'laundryId': laundry_id, 'message': str(exc)})

    summary = {
        'status': 'success',
        'thresholdDays': threshold_days,
        'cutoffIso': cutoff.isoformat(),
        'dryRun': dry_run,
        'ordersScanned': total_scanned,
        'eligibleOrders': len(eligible_orders),
        'updated': len(updated),
        'failed': len(failed),
        'parseErrors': len(parse_errors),
        'updatedDetails': updated,
        'failedDetails': failed,
        'parseErrorDetails': parse_errors,
    }
    logger.info(f"Summary: {summary}")
    return summary


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_utc_timestamp(value):
    """Parse an ISO-8601 timestamp string to a timezone-aware datetime (UTC)."""
    if not value:
        return None
    # DynamoDB stores timestamps like "2026-03-11T19:08:06.200289Z"
    return datetime.fromisoformat(value.replace('Z', '+00:00'))


def _invoke_update_order_status(order_id, laundry_id, employee_id):
    """
    Invoke OrdersInformationService Lambda to set the order status
    to ProcessingCompleted.

    Equivalent HTTP call:
      POST /orders?operation=updateOrder&orderId=...&laundryId=...&empId=...
      Body: { "orderStatus": "ProcessingCompleted", "coupon": null, "servicesToUpdate": [] }
    """
    payload = {
        "queryStringParameters": {
            "operation": "updateOrder",
            "orderId": order_id,
            "laundryId": laundry_id,
            "empId": employee_id,
        },
        "body": json.dumps({
            "orderStatus": "ProcessingCompleted",
            "coupon": None,
            "servicesToUpdate": [],
        }),
    }

    response = lambda_client.invoke(
        FunctionName=ORDERS_INFORMATION_SERVICE_LAMBDA,
        InvocationType='RequestResponse',
        Payload=json.dumps(payload).encode('utf-8'),
    )

    raw = response['Payload'].read().decode('utf-8')
    response_body = json.loads(raw) if raw else {}

    if response.get('FunctionError') or response.get('StatusCode', 200) >= 400:
        raise RuntimeError(
            f"OrdersInformationService returned an error for order {order_id}. "
            f"StatusCode={response.get('StatusCode')}, FunctionError={response.get('FunctionError')}, "
            f"Body={response_body}"
        )

    return response_body
